INSERT INTO tb_student (name, age, email) VALUES ('João Lucas', 26, 'joao.lucas@gmail.com');
INSERT INTO tb_student (name, age, email) VALUES ('Felipe Mendes', 32, 'felipe.mendes@gmail.com');
INSERT INTO tb_student (name, age, email) VALUES ('Charlie Brown', 23, 'charlie.brown@gmail.com');
INSERT INTO tb_student (name, age, email) VALUES ('Luana Dantas', 21, 'luana.dantas@gmail.com');
INSERT INTO tb_student (name, age, email) VALUES ('Carol Ferreira', 27, 'carol.ferreira@gmail.com');
INSERT INTO tb_student (name, age, email) VALUES ('Gabriel Barbosa', 27, 'gabriel.barbosa@gmail.com');
