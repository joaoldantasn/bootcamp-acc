INSERT INTO tb_contato (nome, email) VALUES ('João Lucas', 'joao.lucas@gmail.com');
INSERT INTO tb_contato (nome, email) VALUES ('Felipe Mendes', 'felipe.mendes@gmail.com');
INSERT INTO tb_contato (nome, email) VALUES ('Charlie Brown', 'charlie.brown@gmail.com');
INSERT INTO tb_contato (nome, email) VALUES ('Luana Dantas', 'luana.dantas@gmail.com');
INSERT INTO tb_contato (nome, email) VALUES ('Carol Ferreira', 'carol.ferreira@gmail.com');
INSERT INTO tb_contato (nome, email) VALUES ('Gabriel Barbosa', 'gabriel.barbosa@gmail.com');